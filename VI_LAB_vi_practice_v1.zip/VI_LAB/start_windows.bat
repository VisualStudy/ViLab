@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    py -3 vi_lab.py
) else (
    python vi_lab.py
)
if %ERRORLEVEL% NEQ 0 pause
