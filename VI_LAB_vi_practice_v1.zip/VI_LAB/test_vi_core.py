"""Regression tests: every lesson must be winnable with the documented keys."""
import unittest
from vi_core import LESSONS, ViEngine


LESSON_INPUTS = [
    "h", "l", "j", "k", "0", "$", "w", "b",
    ["i", *"love ", "Escape"],
    ["a", *" is", "Escape"],
    ["o", *"second", "Escape"],
    "x", "dd", "xu", "yy", "p", [":", "w", "Return"], [":", "q", "Return"],
]


class LessonTests(unittest.TestCase):
    def test_every_lesson_can_be_completed(self):
        self.assertEqual(18, len(LESSONS))
        self.assertEqual(len(LESSONS), len(LESSON_INPUTS))
        for index, (lesson, actions) in enumerate(zip(LESSONS, LESSON_INPUTS)):
            with self.subTest(lesson=index + 1, title=lesson.title):
                engine = ViEngine()
                engine.reset(lesson.initial_lines, lesson.initial_cursor, register=("line", "copy me") if index == 15 else None)
                for key in actions:
                    engine.press(key)
                self.assertTrue(lesson.passed(engine, engine.events), f"State: {engine.lines}, cursor={(engine.row, engine.col)}, events={engine.events}")

    def test_target_state_alone_cannot_pass_a_lesson(self):
        lesson = LESSONS[13]  # undo exercise starts with its target buffer
        engine = ViEngine()
        engine.reset(lesson.initial_lines, lesson.initial_cursor)
        self.assertFalse(lesson.passed(engine, []))

    def test_command_q_refuses_unsaved_changes(self):
        e = ViEngine()
        e.reset(("hello",))
        for key in ["x", ":", "q", "Return"]:
            e.press(key)
        self.assertTrue(e.dirty)
        self.assertEqual(e.quit_count, 0)
        self.assertIn("저장되지 않은 변경", e.message)

    def test_w_then_q(self):
        e = ViEngine()
        for key in ["x", ":", "w", "Return", ":", "q", "Return"]:
            e.press(key)
        self.assertEqual((e.save_count, e.quit_count), (1, 1))
        self.assertFalse(e.dirty)

    def test_insert_undo_restores_original(self):
        e = ViEngine()
        e.reset(("abc",), (0, 1))
        for key in ["i", "Z", "Escape", "u"]:
            e.press(key)
        self.assertEqual(e.lines, ["abc"])
        self.assertEqual((e.row, e.col), (0, 1))

    def test_yank_does_not_modify_buffer(self):
        e = ViEngine()
        e.reset(("first", "second"))
        e.press("y")
        e.press("y")
        self.assertEqual(e.lines, ["first", "second"])
        self.assertEqual(e.register, ("line", "first"))
        e.press("p")
        self.assertEqual(e.lines, ["first", "first", "second"])

    def test_typing_korean_character(self):
        e = ViEngine()
        e.reset(("",))
        for key in ["i", "안", "녕", "Escape"]:
            e.press(key)
        self.assertEqual(e.lines, ["안녕"])
        self.assertEqual(e.mode, "NORMAL")

    def test_backspace_newline_join(self):
        e = ViEngine()
        e.reset(("abc",), (0, 0))
        for key in ["a", "Return", "BackSpace", "Escape"]:
            e.press(key)
        self.assertEqual(e.lines, ["abc"])

    def test_escape_cancels_command_line(self):
        e = ViEngine()
        for key in [":", "q", "Escape"]:
            e.press(key)
        self.assertEqual(e.mode, "NORMAL")
        self.assertEqual(e.quit_count, 0)

    def test_no_unsupported_external_side_effects(self):
        e = ViEngine()
        e.press(":")
        e.press("w")
        e.press("Return")
        self.assertEqual(e.save_count, 1)
        self.assertEqual(e.saved_lines, tuple(e.lines))


if __name__ == "__main__":
    unittest.main()
