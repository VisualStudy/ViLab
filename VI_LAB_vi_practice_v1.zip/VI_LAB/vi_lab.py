"""VI LAB: beginner-friendly Korean GUI to practice real vi-style keystrokes.

Run: python vi_lab.py
Requires only the Python standard library and Tkinter (included on most desktop installs).
"""
from __future__ import annotations

import platform
import time
import tkinter as tk
from tkinter import font as tkfont

from vi_core import LESSONS, ViEngine

BG = "#09111F"
SIDE = "#101D30"
PANEL = "#142238"
EDITOR_BG = "#0A1425"
TEAL = "#46D5C3"
WHITE = "#F1F6FF"
LIGHT = "#C6D3E5"
MUTED = "#90A4BD"
BORDER = "#283B55"
SUCCESS = "#8EE2AD"
AMBER = "#F8C87B"


class ViLabApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("VI LAB | vi 편집기 초보자 타자 연습")
        self.root.geometry("1220x810")
        self.root.minsize(980, 670)
        self.root.configure(bg=BG)

        sys = platform.system()
        self.ui_font = "Malgun Gothic" if sys == "Windows" else ("Apple SD Gothic Neo" if sys == "Darwin" else "DejaVu Sans")
        self.code_font = "Consolas" if sys == "Windows" else "DejaVu Sans Mono"
        self.engine = ViEngine()
        self.current_lesson = 0
        self.completed: set[int] = set()
        self.local_events: list[str] = []
        self.total_keystrokes = 0
        self.session_started = time.monotonic()
        self.total_invalid = 0
        self.hint_visible = False

        self._build_layout()
        self.select_lesson(0)
        self.root.bind_all("<KeyPress>", self._on_key, add="+")
        self.root.after(100, self.root.focus_force)
        self.root.after(1000, self._tick)

    def _lbl(self, parent, text, size=11, fg=LIGHT, bg=None, bold=False, **kwargs):
        return tk.Label(
            parent, text=text, bg=bg or parent.cget("bg"), fg=fg,
            font=(self.ui_font, size, "bold" if bold else "normal"),
            **kwargs,
        )

    def _build_layout(self) -> None:
        header = tk.Frame(self.root, bg=BG, height=85)
        header.pack(side="top", fill="x", padx=28, pady=(19, 8))
        header.pack_propagate(False)
        title_container = tk.Frame(header, bg=BG)
        title_container.pack(side="left", fill="y")
        self._lbl(title_container, "VI  LAB", 23, TEAL, bold=True).pack(anchor="w")
        self._lbl(title_container, "키보드로 익히는 vi 편집기  ·  실전 미션 18개", 10, MUTED).pack(anchor="w", pady=(3, 0))
        self._lbl(header, "100% Python  ·  설치형 라이브러리 없음", 10, MUTED).pack(side="right", anchor="ne", pady=14)

        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True, padx=26, pady=(0, 20))

        sidebar = tk.Frame(main, bg=SIDE, width=288, highlightbackground=BORDER, highlightthickness=1)
        sidebar.pack(side="left", fill="y", padx=(0, 15))
        sidebar.pack_propagate(False)
        self._lbl(sidebar, "학습 코스", 14, WHITE, bold=True).pack(anchor="w", padx=18, pady=(20, 4))
        self.progress_label = self._lbl(sidebar, "0 / 18 미션 완료", 10, MUTED)
        self.progress_label.pack(anchor="w", padx=18)
        self.progress_bar = tk.Canvas(sidebar, width=250, height=7, bg="#22354B", bd=0, highlightthickness=0)
        self.progress_bar.pack(anchor="w", padx=18, pady=(9, 18))
        self.progress_fill = self.progress_bar.create_rectangle(0, 0, 0, 7, fill=TEAL, outline="")

        list_holder = tk.Frame(sidebar, bg=SIDE)
        list_holder.pack(fill="both", expand=True, padx=(7, 3))
        self.sidebar_canvas = tk.Canvas(list_holder, bg=SIDE, highlightthickness=0, bd=0)
        sidebar_scroll = tk.Scrollbar(list_holder, orient="vertical", command=self.sidebar_canvas.yview, width=11)
        self.sidebar_canvas.configure(yscrollcommand=sidebar_scroll.set)
        sidebar_scroll.pack(side="right", fill="y")
        self.sidebar_canvas.pack(side="left", fill="both", expand=True)
        self.lesson_list = tk.Frame(self.sidebar_canvas, bg=SIDE)
        self.list_window = self.sidebar_canvas.create_window((0, 0), window=self.lesson_list, anchor="nw")
        self.lesson_list.bind("<Configure>", lambda e: self.sidebar_canvas.configure(scrollregion=self.sidebar_canvas.bbox("all")))
        self.sidebar_canvas.bind("<Configure>", lambda e: self.sidebar_canvas.itemconfig(self.list_window, width=e.width))
        self.sidebar_canvas.bind("<MouseWheel>", self._on_scroll)

        footer = tk.Frame(sidebar, bg="#152942")
        footer.pack(fill="x", side="bottom")
        self._lbl(footer, "빠른 키 가이드", 11, WHITE, bold=True, bg="#152942").pack(anchor="w", padx=16, pady=(13, 7))
        self._lbl(footer, "h ←    j ↓    k ↑    l →", 11, TEAL, bg="#152942").pack(anchor="w", padx=16)
        self._lbl(footer, "i 입력   Esc 복귀   : 명령", 9, LIGHT, bg="#152942").pack(anchor="w", padx=16, pady=(5, 14))

        content = tk.Frame(main, bg=BG)
        content.pack(side="left", fill="both", expand=True)
        mission = tk.Frame(content, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        mission.pack(fill="x", pady=(0, 13))
        titleline = tk.Frame(mission, bg=PANEL)
        titleline.pack(fill="x", padx=21, pady=(19, 5))
        self.mission_num = self._lbl(titleline, "MISSION 01", 10, TEAL, bold=True)
        self.mission_num.pack(side="left")
        self.mission_category = self._lbl(titleline, "", 9, MUTED)
        self.mission_category.pack(side="right")
        self.mission_title = self._lbl(mission, "", 18, WHITE, bold=True, anchor="w", justify="left")
        self.mission_title.pack(fill="x", padx=21)
        self.description_label = self._lbl(mission, "", 10, MUTED, anchor="w", justify="left", wraplength=760)
        self.description_label.pack(fill="x", padx=21, pady=(7, 3))
        self.task_label = self._lbl(mission, "", 11, LIGHT, anchor="w", justify="left", bold=True, wraplength=760)
        self.task_label.pack(fill="x", padx=21, pady=(2, 13))
        cmdrow = tk.Frame(mission, bg=PANEL)
        cmdrow.pack(fill="x", padx=21, pady=(0, 16))
        self._lbl(cmdrow, "추천 입력", 10, MUTED).pack(side="left", padx=(0, 10))
        self.keys_label = self._lbl(cmdrow, "", 11, TEAL, bold=True)
        self.keys_label.pack(side="left")

        stats = tk.Frame(content, bg=BG)
        stats.pack(fill="x", pady=(0, 12))
        self.metric_done = self._metric(stats, "학습 달성", "0 / 18", 0)
        self.metric_keys = self._metric(stats, "키 입력", "0회", 1)
        self.metric_error = self._metric(stats, "지원하지 않는 입력", "0회", 2)
        self.metric_time = self._metric(stats, "연습 시간", "00:00", 3)

        editor_container = tk.Frame(content, bg=EDITOR_BG, highlightbackground=BORDER, highlightthickness=1)
        editor_container.pack(fill="both", expand=True)
        editor_top = tk.Frame(editor_container, bg="#192A40", height=43)
        editor_top.pack(fill="x")
        editor_top.pack_propagate(False)
        self._lbl(editor_top, "●   practice.txt", 11, LIGHT, bold=True, bg="#192A40").pack(side="left", padx=17)
        self.mode_badge = tk.Label(editor_top, text="NORMAL", fg="#032B2A", bg=TEAL,
                                   font=(self.code_font, 10, "bold"), padx=12, pady=5)
        self.mode_badge.pack(side="right", padx=14, pady=7)
        self.editor = tk.Text(editor_container, bg=EDITOR_BG, fg=WHITE,
                              font=(self.code_font, 17), wrap="none",
                              borderwidth=0, highlightthickness=0, insertwidth=0,
                              padx=16, pady=18, cursor="xterm")
        self.editor.pack(fill="both", expand=True)
        self.editor.tag_config("gutter", foreground="#65819E")
        self.editor.tag_config("cursor", background=TEAL, foreground=EDITOR_BG)
        self.editor.tag_config("insert_cursor", foreground=TEAL)
        self.editor.tag_config("active_line", background="#14263C")
        self.editor.bind("<Button-1>", lambda e: "break")
        self.editor.bind("<ButtonRelease-1>", lambda e: "break")
        self.editor.configure(state="disabled")
        commandstrip = tk.Frame(editor_container, bg="#192A40", height=38)
        commandstrip.pack(side="bottom", fill="x")
        commandstrip.pack_propagate(False)
        self.command_text = self._lbl(commandstrip, "-- NORMAL --", 10, TEAL, bg="#192A40")
        self.command_text.pack(side="left", padx=17, pady=8)
        self.position_text = self._lbl(commandstrip, "1:1", 10, MUTED, bg="#192A40")
        self.position_text.pack(side="right", padx=17)

        under = tk.Frame(content, bg=BG)
        under.pack(fill="x", pady=(12, 0))
        self.status_label = self._lbl(under, "", 10, LIGHT, anchor="w", justify="left", wraplength=730)
        self.status_label.pack(fill="x", pady=(0, 10))
        self.hint_label = self._lbl(under, "", 10, AMBER, anchor="w", justify="left", wraplength=730)
        self.hint_label.pack(fill="x")
        actions = tk.Frame(under, bg=BG)
        actions.pack(fill="x", pady=(11, 0))
        self._action_button(actions, "↻  다시 시작", self.restart_lesson, outline=True).pack(side="left")
        self.hint_button = self._action_button(actions, "힌트 보기", self.toggle_hint, outline=True)
        self.hint_button.pack(side="left", padx=(10, 0))
        self.next_button = self._action_button(actions, "다음 미션 →", self.next_lesson, outline=False)
        self.next_button.pack(side="right")

        # Reserve the bottom control area before allocating flexible editor height.
        # Otherwise, at smaller window sizes the editor can hide the buttons.
        under.pack_forget()
        editor_container.pack_forget()
        under.pack(side="bottom", fill="x", pady=(12, 0))
        editor_container.pack(side="top", fill="both", expand=True)

    def _metric(self, parent, caption, number, col):
        card = tk.Frame(parent, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        card.pack(side="left", fill="x", expand=True, padx=(0, 8) if col < 3 else 0)
        self._lbl(card, caption, 9, MUTED).pack(anchor="w", padx=14, pady=(9, 2))
        value = self._lbl(card, number, 14, WHITE, bold=True)
        value.pack(anchor="w", padx=14, pady=(0, 9))
        return value

    def _action_button(self, parent, title, command, outline=False):
        return tk.Button(parent, text=title, command=command,
                         bg=SIDE if outline else TEAL,
                         fg=LIGHT if outline else "#09232A",
                         activebackground="#25445A" if outline else "#70E2D4",
                         activeforeground=WHITE if outline else "#09232A",
                         bd=0, relief="flat", cursor="hand2",
                         font=(self.ui_font, 10, "bold"), padx=19, pady=10)

    def _tick(self):
        elapsed = int(time.monotonic() - self.session_started)
        self.metric_time.configure(text=f"{elapsed // 60:02d}:{elapsed % 60:02d}")
        self.root.after(1000, self._tick)

    def _on_scroll(self, event):
        self.sidebar_canvas.yview_scroll(-1 * int(event.delta / 120), "units")

    def _render_sidebar(self):
        for child in self.lesson_list.winfo_children():
            child.destroy()
        last_group = None
        for ix, lesson in enumerate(LESSONS):
            if lesson.group != last_group:
                self._lbl(self.lesson_list, lesson.group, 9, MUTED, bold=True).pack(anchor="w", padx=12, pady=(14, 7))
                last_group = lesson.group
            selected = ix == self.current_lesson
            done = ix in self.completed
            fill = "#215063" if selected else SIDE
            label = ("✓" if done else f"{ix + 1:02d}") + "   " + lesson.title
            btn = tk.Button(self.lesson_list, text=label, command=lambda i=ix: self.select_lesson(i),
                            bg=fill, fg=TEAL if selected or done else LIGHT,
                            activebackground="#28425B", activeforeground=WHITE,
                            font=(self.ui_font, 10, "bold" if selected else "normal"),
                            anchor="w", padx=13, pady=9, relief="flat", bd=0, cursor="hand2")
            btn.pack(fill="x", padx=5, pady=1)

    def select_lesson(self, ix: int):
        self.current_lesson = ix
        lesson = LESSONS[ix]
        register = ("line", "copy me") if ix == 15 else None
        self.engine.reset(lesson.initial_lines, lesson.initial_cursor, register=register)
        self.local_events = []
        self.hint_visible = False
        self.hint_label.configure(text="")
        self.hint_button.configure(text="힌트 보기")
        self.mission_num.configure(text=f"MISSION {ix + 1:02d} / {len(LESSONS)}")
        self.mission_category.configure(text=lesson.group)
        self.mission_title.configure(text=lesson.title)
        self.description_label.configure(text=lesson.description)
        self.task_label.configure(text="목표  " + lesson.instruction)
        self.keys_label.configure(text=lesson.keys)
        self._render_sidebar()
        self._render()
        self.root.focus_force()

    def restart_lesson(self):
        self.select_lesson(self.current_lesson)

    def toggle_hint(self):
        self.hint_visible = not self.hint_visible
        self.hint_label.configure(text=("💡 " + LESSONS[self.current_lesson].hint) if self.hint_visible else "")
        self.hint_button.configure(text="힌트 숨기기" if self.hint_visible else "힌트 보기")
        self.root.focus_force()

    def next_lesson(self):
        self.select_lesson((self.current_lesson + 1) % len(LESSONS))

    def _on_key(self, event):
        if event.state & 0x4:  # avoid interfering with Control shortcuts
            return
        special = {"Escape": "Escape", "Return": "Return", "KP_Enter": "Return",
                   "BackSpace": "BackSpace", "Tab": "Tab"}
        key = special.get(event.keysym)
        if key is None:
            key = event.char if event.char else event.keysym
        before_invalid = self.engine.invalid_keys
        before_events = len(self.engine.events)
        consumed = self.engine.press(key)
        if consumed or self.engine.invalid_keys != before_invalid:
            self.total_keystrokes += 1
            self.total_invalid += self.engine.invalid_keys - before_invalid
            self.local_events.extend(self.engine.events[before_events:])
            if LESSONS[self.current_lesson].passed(self.engine, self.local_events):
                if self.current_lesson not in self.completed:
                    self.completed.add(self.current_lesson)
                    self._render_sidebar()
            self._render()
            return "break"
        return None

    def _render(self):
        self.editor.configure(state="normal")
        self.editor.delete("1.0", "end")
        for r, line in enumerate(self.engine.lines):
            self.editor.insert("end", f"{r + 1:>2} │ ", "gutter")
            if r == self.engine.row and self.engine.mode == "INSERT":
                at = min(self.engine.col, len(line))
                self.editor.insert("end", line[:at])
                self.editor.insert("end", "▏", "insert_cursor")
                self.editor.insert("end", line[at:])
            elif r == self.engine.row:
                if line:
                    at = min(self.engine.col, len(line) - 1)
                    self.editor.insert("end", line[:at])
                    self.editor.insert("end", line[at], "cursor")
                    self.editor.insert("end", line[at + 1:])
                else:
                    self.editor.insert("end", " ", "cursor")
            else:
                self.editor.insert("end", line)
            if r != len(self.engine.lines) - 1:
                self.editor.insert("end", "\n")
        self.editor.configure(state="disabled")
        if self.engine.mode == "INSERT":
            self.mode_badge.configure(text="INSERT", bg=AMBER, fg="#34260D")
        elif self.engine.mode == "COMMAND":
            self.mode_badge.configure(text="COMMAND", bg="#A8B5FF", fg="#171D50")
        else:
            self.mode_badge.configure(text="NORMAL", bg=TEAL, fg="#032B2A")
        self.command_text.configure(text=(self.engine.command_line if self.engine.mode == "COMMAND" else f"-- {self.engine.mode} --"))
        self.position_text.configure(text=f"Ln {self.engine.row + 1}, Col {self.engine.col + 1}")
        completed = self.current_lesson in self.completed
        if completed:
            self.status_label.configure(text="✓ 미션 완료! 잘했습니다. 다음 미션으로 이동할 수 있습니다.", fg=SUCCESS)
        else:
            self.status_label.configure(text=self.engine.message, fg=AMBER if self.engine.invalid_keys else LIGHT)
        self.metric_done.configure(text=f"{len(self.completed)} / {len(LESSONS)}")
        self.metric_keys.configure(text=f"{self.total_keystrokes}회")
        self.metric_error.configure(text=f"{self.total_invalid}회")
        self.progress_label.configure(text=f"{len(self.completed)} / {len(LESSONS)} 미션 완료")
        self.progress_bar.coords(self.progress_fill, 0, 0, int(250 * len(self.completed) / len(LESSONS)), 7)
        self.next_button.configure(text="마지막 미션 ✓" if completed and self.current_lesson == len(LESSONS)-1 else "다음 미션 →")


def main() -> None:
    root = tk.Tk()
    ViLabApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
