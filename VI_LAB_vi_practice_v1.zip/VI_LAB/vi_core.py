"""Small, deterministic vi practice engine (educational subset of vi)."""
from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Optional


@dataclass(frozen=True)
class Lesson:
    title: str
    group: str
    description: str
    instruction: str
    hint: str
    keys: str
    initial_lines: tuple[str, ...]
    initial_cursor: tuple[int, int]
    required_events: tuple[str, ...]
    target_lines: Optional[tuple[str, ...]] = None
    target_cursor: Optional[tuple[int, int]] = None
    target_register: Optional[tuple[str, str]] = None
    min_saves: int = 0
    min_quits: int = 0

    def passed(self, engine: "ViEngine", events: list[str]) -> bool:
        return (
            engine.mode == "NORMAL"
            and all(event in events for event in self.required_events)
            and (self.target_lines is None or tuple(engine.lines) == self.target_lines)
            and (self.target_cursor is None or (engine.row, engine.col) == self.target_cursor)
            and (self.target_register is None or engine.register == self.target_register)
            and engine.save_count >= self.min_saves
            and engine.quit_count >= self.min_quits
        )


LESSONS = [
    Lesson("왼쪽으로 이동", "01 이동 기초", "h 키는 커서를 한 칸 왼쪽으로 이동합니다.", "D 위에 있는 커서를 C로 이동하세요.", "일반 모드에서 h를 한 번 누르세요.", "h", ("ABCDE",), (0, 3), ("h",), target_cursor=(0, 2)),
    Lesson("오른쪽으로 이동", "01 이동 기초", "l 키는 커서를 한 칸 오른쪽으로 이동합니다.", "B 위에 있는 커서를 C로 이동하세요.", "영문 소문자 L(l)을 누르세요.", "l", ("ABCDE",), (0, 1), ("l",), target_cursor=(0, 2)),
    Lesson("아래 줄로 이동", "01 이동 기초", "j 키는 커서를 아래 줄로 이동합니다.", "첫 번째 줄에서 두 번째 줄로 이동하세요.", "방향키 대신 j를 사용하세요.", "j", ("one", "two", "three"), (0, 1), ("j",), target_cursor=(1, 1)),
    Lesson("위 줄로 이동", "01 이동 기초", "k 키는 커서를 위 줄로 이동합니다.", "세 번째 줄에서 두 번째 줄로 이동하세요.", "k는 위쪽입니다.", "k", ("one", "two", "three"), (2, 1), ("k",), target_cursor=(1, 1)),
    Lesson("줄 맨 앞으로", "02 빠른 이동", "0은 현재 줄의 첫 문자로 이동합니다.", "커서를 줄의 맨 앞으로 옮기세요.", "숫자 0을 누르세요. 영문 O가 아닙니다.", "0", ("learning vi",), (0, 6), ("0",), target_cursor=(0, 0)),
    Lesson("줄 맨 뒤로", "02 빠른 이동", "$는 현재 줄의 마지막 문자로 이동합니다.", "커서를 줄의 맨 뒤로 옮기세요.", "Shift+4로 $를 입력하세요(영문 키보드 기준).", "$", ("learning vi",), (0, 0), ("$",), target_cursor=(0, 10)),
    Lesson("다음 단어로", "02 빠른 이동", "w는 다음 단어의 시작 위치로 이동합니다.", "one에서 two의 첫 글자로 이동하세요.", "w는 word(단어)의 첫 글자입니다.", "w", ("one two three",), (0, 0), ("w",), target_cursor=(0, 4)),
    Lesson("이전 단어로", "02 빠른 이동", "b는 이전 단어의 시작 위치로 이동합니다.", "three에서 two의 첫 글자로 이동하세요.", "b는 back(뒤로)과 연결해서 기억하세요.", "b", ("one two three",), (0, 8), ("b",), target_cursor=(0, 4)),
    Lesson("i로 문자 입력", "03 입력 모드", "i는 커서 앞에서 입력 모드로 전환합니다.", "I vi 문장을 I love vi로 바꾸고 일반 모드로 돌아오세요.", "i → love 뒤에 공백 1개 → Esc 순서입니다.", "i  →  love␣  →  Esc", ("I vi",), (0, 2), ("i", "Esc"), target_lines=("I love vi",)),
    Lesson("a로 문자 덧붙이기", "03 입력 모드", "a는 커서 뒤에서 입력 모드로 전환합니다.", "vi fun을 vi is fun으로 바꾸세요.", "a → 공백 + is → Esc를 사용하세요.", "a  →  ␣is  →  Esc", ("vi fun",), (0, 1), ("a", "Esc"), target_lines=("vi is fun",)),
    Lesson("o로 아래 줄 열기", "03 입력 모드", "o는 현재 줄 아래에 새 줄을 만들고 입력 모드로 들어갑니다.", "first와 third 사이에 second를 입력하세요.", "첫 번째 줄에서 o → second → Esc를 누르세요.", "o  →  second  →  Esc", ("first", "third"), (0, 1), ("o", "Esc"), target_lines=("first", "second", "third")),
    Lesson("x로 글자 삭제", "04 수정과 복구", "x는 커서 아래의 한 글자를 삭제합니다.", "helllo에서 중복된 l 하나를 삭제하세요.", "커서에 강조 표시된 l을 x로 삭제하세요.", "x", ("helllo",), (0, 3), ("x",), target_lines=("hello",)),
    Lesson("dd로 한 줄 삭제", "04 수정과 복구", "dd는 현재 줄 전체를 삭제합니다.", "remove 줄을 삭제하세요.", "d를 연속으로 두 번 누르세요.", "d  d", ("keep", "remove", "next"), (1, 0), ("dd",), target_lines=("keep", "next")),
    Lesson("u로 실행 취소", "04 수정과 복구", "u는 직전 텍스트 변경을 취소합니다.", "x로 첫 글자를 지운 뒤, u로 복구하세요.", "x를 눌러 지웠다가 u로 되돌리세요.", "x  →  u", ("undo me",), (0, 0), ("x", "u"), target_lines=("undo me",)),
    Lesson("yy로 한 줄 복사", "05 복사와 붙여넣기", "yy는 현재 줄을 임시 레지스터에 복사합니다.", "copy me 줄을 yy로 복사하세요.", "y를 연속해서 두 번 누르세요. 화면은 그대로여도 정상입니다.", "y  y", ("copy me", "another"), (0, 0), ("yy",), target_register=("line", "copy me")),
    Lesson("p로 붙여넣기", "05 복사와 붙여넣기", "p는 복사한 줄을 현재 줄 아래에 붙여넣습니다.", "copy me 줄을 바로 아래에 하나 더 만드세요.", "복사한 내용이 이미 준비되어 있습니다. p를 누르세요.", "p", ("copy me", "another"), (0, 0), ("p",), target_lines=("copy me", "copy me", "another")),
    Lesson(":w로 저장", "06 명령행", ":w는 파일을 저장하는 명령입니다. 이 앱에서는 메모리에 저장을 시뮬레이션합니다.", ":w를 입력하고 Enter를 누르세요.", "일반 모드에서 :를 누른 다음 w, Enter 순서입니다.", ":w  →  Enter", ("practice file",), (0, 0), (":w",), min_saves=1),
    Lesson(":q로 종료", "06 명령행", ":q는 저장되지 않은 변경이 없을 때 파일을 닫습니다. 이 앱은 종료를 시뮬레이션합니다.", ":q를 입력하고 Enter를 누르세요.", "일반 모드에서 :q를 입력한 뒤 Enter를 누르세요.", ":q  →  Enter", ("finished!",), (0, 0), (":q",), min_quits=1),
]


class ViEngine:
    """A deliberately limited vi teaching engine, not a real file editor."""

    def __init__(self) -> None:
        self.reset(("hello vi",), (0, 0))

    def reset(
        self,
        lines: tuple[str, ...] | list[str],
        cursor: tuple[int, int] = (0, 0),
        register: Optional[tuple[str, str]] = None,
    ) -> None:
        self.lines = list(lines) if lines else [""]
        self.row = max(0, min(cursor[0], len(self.lines) - 1))
        self.col = max(0, min(cursor[1], max(0, len(self.lines[self.row]) - 1)))
        self.mode = "NORMAL"
        self.pending = ""
        self.command_line = ""
        self.register = register
        self.undo_stack: list[tuple[list[str], int, int]] = []
        self.saved_lines = tuple(self.lines)
        self.save_count = 0
        self.quit_count = 0
        self.keystrokes = 0
        self.invalid_keys = 0
        self.events: list[str] = []
        self.message = "키보드로 연습을 시작하세요."

    @property
    def dirty(self) -> bool:
        return tuple(self.lines) != self.saved_lines

    def _snapshot(self) -> None:
        self.undo_stack.append((self.lines.copy(), self.row, self.col))
        if len(self.undo_stack) > 50:
            self.undo_stack.pop(0)

    def _normal_col(self) -> None:
        self.col = min(self.col, max(0, len(self.lines[self.row]) - 1))

    def _record(self, action: str) -> None:
        self.events.append(action)
        self.message = f"명령 실행: {action}"

    def _move_vertical(self, delta: int, action: str) -> None:
        newrow = max(0, min(self.row + delta, len(self.lines) - 1))
        if newrow != self.row:
            self.row = newrow
            self._normal_col()
            self._record(action)
        else:
            self.message = "더 이상 이동할 줄이 없습니다."

    def _move_word(self, backward: bool) -> None:
        action = "b" if backward else "w"
        starts = [m.start() for m in re.finditer(r"\w+|[^\w\s]+", self.lines[self.row])]
        candidates = [i for i in starts if i < self.col] if backward else [i for i in starts if i > self.col]
        if candidates:
            self.col = candidates[-1] if backward else candidates[0]
            self._record(action)
            return
        remaining = range(self.row - 1, -1, -1) if backward else range(self.row + 1, len(self.lines))
        for r in remaining:
            starts = [m.start() for m in re.finditer(r"\w+|[^\w\s]+", self.lines[r])]
            if starts:
                self.row = r
                self.col = starts[-1] if backward else starts[0]
                self._record(action)
                return
        self.message = "이동할 단어가 없습니다."

    def press(self, key: str) -> bool:
        """Process one keystroke. Return True when the key is consumed.

        Printable characters are passed as one-character strings; specials use
        'Escape', 'Return', 'BackSpace'.
        """
        if key in {"Shift_L", "Shift_R", "Control_L", "Control_R", "Alt_L", "Alt_R", "Caps_Lock"}:
            return False
        self.keystrokes += 1
        if self.mode == "INSERT":
            return self._insert_key(key)
        if self.mode == "COMMAND":
            return self._command_key(key)
        return self._normal_key(key)

    def _insert_key(self, key: str) -> bool:
        if key == "Escape":
            self.mode = "NORMAL"
            self._normal_col_after_insert()
            self._record("Esc")
            return True
        if key == "BackSpace":
            if self.col > 0:
                line = self.lines[self.row]
                self.lines[self.row] = line[:self.col - 1] + line[self.col:]
                self.col -= 1
            elif self.row > 0:
                previous = self.lines[self.row - 1]
                self.col = len(previous)
                self.lines[self.row - 1] += self.lines.pop(self.row)
                self.row -= 1
            self.message = "입력 모드: 글자 삭제"
            return True
        if key == "Return":
            line = self.lines[self.row]
            self.lines[self.row] = line[:self.col]
            self.lines.insert(self.row + 1, line[self.col:])
            self.row += 1
            self.col = 0
            self.message = "입력 모드: 줄 바꿈"
            return True
        if key == "Tab":
            key = "    "
        if key and key.isprintable():
            line = self.lines[self.row]
            self.lines[self.row] = line[:self.col] + key + line[self.col:]
            self.col += len(key)
            self.message = "입력 중 · Esc로 일반 모드 복귀"
            return True
        return False

    def _normal_col_after_insert(self) -> None:
        self.col = max(0, min(self.col - 1, len(self.lines[self.row]) - 1)) if self.lines[self.row] else 0

    def _command_key(self, key: str) -> bool:
        if key == "Escape":
            self.mode = "NORMAL"
            self.command_line = ""
            self.message = "명령 입력 취소"
            return True
        if key == "BackSpace":
            self.command_line = self.command_line[:-1]
            if not self.command_line:
                self.mode = "NORMAL"
            return True
        if key == "Return":
            cmd = self.command_line
            self.mode = "NORMAL"
            self.command_line = ""
            if cmd == ":w":
                self.saved_lines = tuple(self.lines)
                self.save_count += 1
                self._record(":w")
                self.message = "저장 완료 (연습용 메모리 저장 · 실제 파일 생성 없음)"
            elif cmd == ":q":
                if self.dirty:
                    self.message = "저장되지 않은 변경이 있습니다. :w 또는 :q!를 사용하세요."
                else:
                    self.quit_count += 1
                    self._record(":q")
                    self.message = "종료 명령 성공 (연습 앱은 종료되지 않습니다)"
            elif cmd == ":wq":
                self.saved_lines = tuple(self.lines)
                self.save_count += 1
                self.quit_count += 1
                self._record(":wq")
                self.message = "저장 후 종료 명령 성공 (시뮬레이션)"
            elif cmd == ":q!":
                self.quit_count += 1
                self._record(":q!")
                self.message = "저장하지 않고 종료 명령 성공 (시뮬레이션)"
            else:
                self.invalid_keys += 1
                self.message = f"아직 지원하지 않는 명령: {cmd}"
            return True
        if len(key) == 1 and key.isprintable():
            self.command_line += key
            return True
        return False

    def _normal_key(self, key: str) -> bool:
        if key == "Escape":
            self.pending = ""
            self.message = "일반 모드"
            return True
        if self.pending:
            pending = self.pending
            self.pending = ""
            if pending == "d" and key == "d":
                self._snapshot()
                self.register = ("line", self.lines[self.row])
                if len(self.lines) == 1:
                    self.lines[0] = ""
                else:
                    self.lines.pop(self.row)
                    self.row = min(self.row, len(self.lines) - 1)
                self._normal_col()
                self._record("dd")
                return True
            if pending == "y" and key == "y":
                self.register = ("line", self.lines[self.row])
                self._record("yy")
                return True
            self.invalid_keys += 1
            self.message = f"'{pending}{key}' 명령은 지원하지 않습니다. 다시 시도하세요."
            return True
        if key in ("d", "y"):
            self.pending = key
            self.message = f"{key} 입력됨 · 한 번 더 {key}를 누르세요"
            return True
        if key == ":":
            self.mode = "COMMAND"
            self.command_line = ":"
            self.message = "명령행 입력 · Enter로 실행"
            return True
        if key == "h":
            if self.col > 0:
                self.col -= 1
                self._record("h")
            else:
                self.message = "줄의 시작입니다."
        elif key == "l":
            if self.col < len(self.lines[self.row]) - 1:
                self.col += 1
                self._record("l")
            else:
                self.message = "줄의 끝입니다."
        elif key == "j":
            self._move_vertical(+1, "j")
        elif key == "k":
            self._move_vertical(-1, "k")
        elif key == "0":
            self.col = 0
            self._record("0")
        elif key == "$":
            self.col = max(0, len(self.lines[self.row]) - 1)
            self._record("$")
        elif key == "w":
            self._move_word(False)
        elif key == "b":
            self._move_word(True)
        elif key in ("i", "a", "o"):
            self._snapshot()
            if key == "a":
                self.col = min(self.col + 1, len(self.lines[self.row])) if self.lines[self.row] else 0
            if key == "o":
                self.lines.insert(self.row + 1, "")
                self.row += 1
                self.col = 0
            self.mode = "INSERT"
            self._record(key)
            self.message = "입력 모드 · Esc로 일반 모드 복귀"
        elif key == "x":
            line = self.lines[self.row]
            if line:
                self._snapshot()
                self.register = ("char", line[self.col])
                self.lines[self.row] = line[:self.col] + line[self.col + 1:]
                self._normal_col()
                self._record("x")
            else:
                self.message = "삭제할 문자가 없습니다."
        elif key == "p":
            if not self.register:
                self.message = "붙여넣을 내용이 없습니다. 먼저 yy 또는 x를 사용하세요."
            else:
                self._snapshot()
                kind, value = self.register
                if kind == "line":
                    self.lines.insert(self.row + 1, value)
                    self.row += 1
                    self.col = 0
                else:
                    pos = self.col + 1 if self.lines[self.row] else 0
                    line = self.lines[self.row]
                    self.lines[self.row] = line[:pos] + value + line[pos:]
                    self.col = pos + len(value) - 1
                self._record("p")
        elif key == "u":
            if self.undo_stack:
                self.lines, self.row, self.col = self.undo_stack.pop()
                self._record("u")
            else:
                self.message = "취소할 변경이 없습니다."
        else:
            if len(key) == 1 and key.isprintable():
                self.invalid_keys += 1
                self.message = f"'{key}'는 이 연습 앱에서 지원하지 않는 일반 모드 키입니다."
            return False
        return True
